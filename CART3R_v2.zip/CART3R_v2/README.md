# CART3R Trading Bot v2.0

Educational RSI + EMA paper-trading dashboard. It does not connect to Pocket Option or place real trades.

## Run on a computer
1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Run:
   ```bash
   python -m pip install -r requirements.txt
   streamlit run app.py
   ```
4. Open the local URL printed by Streamlit.

## Run from a phone
The easiest route is to deploy the project to a Streamlit-compatible hosting service using a GitHub repository, then open the resulting app URL in Safari/Chrome. A computer is usually easier for the initial setup. A phone-only workflow is possible with a cloud coding environment, but setup may be less convenient.

## CSV format
Required columns: timestamp, open, high, low, close.
Use one row per candle, sorted by time. Prices must be positive.

## Stop-loss clarification
The dashboard displays an ATR-based hypothetical risk reference for education. It is not a broker stop-loss order and must not be entered as an instruction on Pocket Option. Fixed-time contracts may not support conventional price-based stop-loss orders.

## Limitations
- Demo candles are synthetic, not live prices.
- The payout is an assumption selected in the sidebar.
- Results do not prove a strategy has an edge.
- Backtesting is simplified and does not model all market/broker execution conditions.
