import math
import numpy as np
import pandas as pd
import streamlit as st
import plotly.graph_objects as go
from plotly.subplots import make_subplots

st.set_page_config(page_title="CART3R v2.0", page_icon="📊", layout="wide")

st.markdown("""
<style>
.stApp { background: #080808; color: #eeeeee; }
[data-testid="stSidebar"] { background: #110909; }
h1,h2,h3 { color: #ff4545 !important; }
div[data-testid="stMetric"] {
    background: #160b0b; border: 1px solid #692020;
    padding: 12px; border-radius: 12px;
}
div.stButton > button {
    background: #8f1717; color: white; border: 1px solid #ff4545;
    border-radius: 9px;
}
.notice {
    background: #241414; border: 1px solid #a13a3a;
    border-radius: 10px; padding: 12px; margin: 8px 0;
}
.small { color: #aaaaaa; font-size: 0.85rem; }
</style>
""", unsafe_allow_html=True)

st.title("🔴 CART3R TRADING BOT")
st.caption("VERSION 2.0 • RSI + EMA • EDUCATIONAL PAPER-TRADING ONLY")
st.markdown(
    '<div class="notice"><b>SIMULATION ONLY.</b> This app does not connect to '
    'Pocket Option, place trades, or provide real-time broker prices. '
    'No real money is used.</div>', unsafe_allow_html=True
)

def make_demo(n=500, seed=42):
    rng = np.random.default_rng(seed)
    times = pd.date_range("2026-01-01", periods=n, freq="min")
    noise = rng.normal(0, 0.0018, n)
    drift = 0.00012 * np.sin(np.arange(n) / 24)
    close = 100 * np.exp(np.cumsum(noise + drift))
    open_ = np.r_[close[0], close[:-1]]
    spread = rng.uniform(0.0001, 0.0010, n) * close
    high = np.maximum(open_, close) + spread
    low = np.minimum(open_, close) - spread
    return pd.DataFrame({"timestamp": times, "open": open_, "high": high,
                         "low": low, "close": close})

def validate_data(df):
    required = {"timestamp", "open", "high", "low", "close"}
    if not required.issubset(df.columns):
        raise ValueError("CSV needs timestamp, open, high, low, close columns.")
    df = df.copy()
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    for c in ["open", "high", "low", "close"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna(subset=["timestamp", "open", "high", "low", "close"])
    if len(df) < 60:
        raise ValueError("Please provide at least 60 valid candles.")
    if (df[["open", "high", "low", "close"]] <= 0).any().any():
        raise ValueError("Prices must be positive.")
    if (df["high"] < df[["open", "close"]].max(axis=1)).any():
        raise ValueError("Found a candle with high below open/close.")
    if (df["low"] > df[["open", "close"]].min(axis=1)).any():
        raise ValueError("Found a candle with low above open/close.")
    return df.sort_values("timestamp").reset_index(drop=True)

def add_indicators(df, rsi_period, fast_period, slow_period):
    x = df.copy()
    x["ema_fast"] = x.close.ewm(span=fast_period, adjust=False, min_periods=fast_period).mean()
    x["ema_slow"] = x.close.ewm(span=slow_period, adjust=False, min_periods=slow_period).mean()
    delta = x.close.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1/rsi_period, adjust=False, min_periods=rsi_period).mean()
    avg_loss = loss.ewm(alpha=1/rsi_period, adjust=False, min_periods=rsi_period).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    x["rsi"] = 100 - (100 / (1 + rs))
    x.loc[(avg_loss == 0) & (avg_gain > 0), "rsi"] = 100
    x.loc[(avg_loss == 0) & (avg_gain == 0), "rsi"] = 50
    return x

def build_signals(df):
    x = df.copy()
    prev_fast = x.ema_fast.shift(1)
    prev_slow = x.ema_slow.shift(1)
    cross_up = (prev_fast <= prev_slow) & (x.ema_fast > x.ema_slow)
    cross_down = (prev_fast >= prev_slow) & (x.ema_fast < x.ema_slow)
    x["signal"] = "HOLD"
    x.loc[cross_up & x.rsi.between(50, 70, inclusive="neither") &
          (x.close > x.ema_fast), "signal"] = "CALL"
    x.loc[cross_down & x.rsi.between(30, 50, inclusive="neither") &
          (x.close < x.ema_fast), "signal"] = "PUT"
    return x

def backtest(df, start_balance, risk_pct, payout, expiry, atr_mult):
    balance = float(start_balance)
    trades = []
    # Signal is known only after candle i closes; entry is next candle open.
    i = 1
    while i + expiry - 1 < len(df):
        signal = df.iloc[i].signal
        if signal not in ("CALL", "PUT"):
            i += 1
            continue
        entry_i = i + 1
        exit_i = entry_i + expiry - 1
        if exit_i >= len(df):
            break
        entry = float(df.iloc[entry_i].open)
        exit_price = float(df.iloc[exit_i].close)
        stake = balance * risk_pct / 100
        if stake <= 0:
            break
        if math.isclose(entry, exit_price, rel_tol=1e-12, abs_tol=1e-12):
            result, pnl = "DRAW", 0.0
        elif (signal == "CALL" and exit_price > entry) or (signal == "PUT" and exit_price < entry):
            result, pnl = "WIN", stake * payout
        else:
            result, pnl = "LOSS", -stake
        # ATR-derived educational reference only; not an executable stop.
        atr = float(df.iloc[entry_i].atr) if pd.notna(df.iloc[entry_i].atr) else 0.0
        reference = entry - atr_mult * atr if signal == "CALL" else entry + atr_mult * atr
        balance += pnl
        trades.append({
            "Direction": signal, "Signal time": df.iloc[i].timestamp,
            "Entry time": df.iloc[entry_i].timestamp, "Expiry time": df.iloc[exit_i].timestamp,
            "Entry": entry, "Exit": exit_price, "Virtual stake": stake,
            "Hypothetical risk reference": reference,
            "Result": result, "P/L": pnl, "Balance": balance
        })
        i = exit_i + 1
    return pd.DataFrame(trades), balance

with st.sidebar:
    st.header("⚙️ Configuration")
    uploaded = st.file_uploader("Upload OHLC CSV (optional)", type=["csv"])
    st.caption("CSV columns: timestamp, open, high, low, close")
    st.divider()
    st.subheader("Indicators")
    rsi_period = st.number_input("RSI period", 2, 50, 14)
    fast_period = st.number_input("Fast EMA", 2, 50, 9)
    slow_period = st.number_input("Slow EMA", 3, 100, 21)
    st.subheader("Paper account")
    starting_balance = st.number_input("Virtual starting balance", min_value=100.0, value=10000.0, step=500.0)
    risk_pct = st.slider("Virtual stake (% of balance)", 0.1, 2.0, 1.0, 0.1)
    payout = st.slider("Assumed payout (simulation only)", 0.10, 0.95, 0.80, 0.05)
    expiry = st.number_input("Expiry (candles)", 1, 30, 5)
    atr_mult = st.slider("ATR reference multiplier", 0.5, 4.0, 1.5, 0.1)
    st.divider()
    st.caption("Demo data is synthetic. It is not a market feed.")

try:
    raw = pd.read_csv(uploaded) if uploaded is not None else make_demo()
    data = validate_data(raw)
    data = add_indicators(data, int(rsi_period), int(fast_period), int(slow_period))
    # ATR for an educational chart reference.
    prev_close = data.close.shift(1)
    tr = pd.concat([
        data.high - data.low,
        (data.high - prev_close).abs(),
        (data.low - prev_close).abs()
    ], axis=1).max(axis=1)
    data["atr"] = tr.rolling(14, min_periods=14).mean()
    data = build_signals(data)
    trades, final_balance = backtest(
        data, starting_balance, risk_pct, payout, int(expiry), atr_mult
    )
except Exception as e:
    st.error(f"Data error: {e}")
    st.stop()

wins = int((trades.Result == "WIN").sum()) if not trades.empty else 0
losses = int((trades.Result == "LOSS").sum()) if not trades.empty else 0
draws = int((trades.Result == "DRAW").sum()) if not trades.empty else 0
decisive = wins + losses
win_rate = wins / decisive * 100 if decisive else 0.0
net = final_balance - starting_balance
roi = net / starting_balance * 100
gross_win = trades.loc[trades["P/L"] > 0, "P/L"].sum() if not trades.empty else 0
gross_loss = abs(trades.loc[trades["P/L"] < 0, "P/L"].sum()) if not trades.empty else 0
pf = gross_win / gross_loss if gross_loss else float("nan")

last = data.iloc[-1]
latest_signal = last.signal
c1, c2, c3, c4, c5 = st.columns(5)
c1.metric("Virtual balance", f"{final_balance:,.2f}", f"{net:+,.2f}")
c2.metric("Signals traded", str(len(trades)))
c3.metric("Win rate", f"{win_rate:.1f}%")
c4.metric("Virtual P/L", f"{roi:+.2f}%")
c5.metric("Latest signal", latest_signal)

tab1, tab2, tab3, tab4 = st.tabs(["📈 Market chart", "🧭 Signal & risk", "📋 Trade history", "📊 Performance"])

with tab1:
    st.subheader("Candlestick chart + EMA")
    fig = go.Figure()
    fig.add_trace(go.Candlestick(
        x=data.timestamp, open=data.open, high=data.high,
        low=data.low, close=data.close, name="Price"
    ))
    fig.add_trace(go.Scatter(x=data.timestamp, y=data.ema_fast, name=f"EMA {fast_period}", line=dict(width=1.5)))
    fig.add_trace(go.Scatter(x=data.timestamp, y=data.ema_slow, name=f"EMA {slow_period}", line=dict(width=1.5)))
    if not trades.empty:
        for direction, marker in [("CALL", "triangle-up"), ("PUT", "triangle-down")]:
            subset = trades[trades.Direction == direction]
            fig.add_trace(go.Scatter(
                x=subset["Entry time"], y=subset.Entry, mode="markers",
                name=f"{direction} simulated entries",
                marker=dict(symbol=marker, size=10)
            ))
    fig.update_layout(template="plotly_dark", height=480, xaxis_rangeslider_visible=False,
                      paper_bgcolor="#080808", plot_bgcolor="#080808", legend_orientation="h")
    st.plotly_chart(fig, use_container_width=True)

    st.subheader("RSI")
    rfig = go.Figure()
    rfig.add_trace(go.Scatter(x=data.timestamp, y=data.rsi, name="RSI 14"))
    rfig.add_hline(y=70, line_dash="dash")
    rfig.add_hline(y=50, line_dash="dot")
    rfig.add_hline(y=30, line_dash="dash")
    rfig.update_yaxes(range=[0, 100])
    rfig.update_layout(template="plotly_dark", height=230, paper_bgcolor="#080808", plot_bgcolor="#080808")
    st.plotly_chart(rfig, use_container_width=True)

with tab2:
    st.subheader("Latest candle analysis")
    a, b, c = st.columns(3)
    a.metric("Last close", f"{last.close:.5f}")
    a.metric(f"EMA {fast_period}", f"{last.ema_fast:.5f}" if pd.notna(last.ema_fast) else "N/A")
    a.metric("RSI", f"{last.rsi:.2f}" if pd.notna(last.rsi) else "N/A")
    st.write(f"**Latest closed-candle signal:** `{latest_signal}`")
    if latest_signal == "HOLD":
        st.info("No qualifying EMA crossover + RSI confirmation on the latest candle.")
    elif latest_signal == "CALL":
        st.success("The rules detected a simulated bullish setup.")
    else:
        st.warning("The rules detected a simulated bearish setup.")
    st.markdown("### Hypothetical risk reference")
    st.warning(
        "This is an ATR-based analysis level for learning only. It is NOT a stop-loss "
        "order, cannot be sent to Pocket Option, and should not be copied into a live trade. "
        "Fixed-time contracts may not offer a conventional price-based stop-loss."
    )
    if not trades.empty:
        t = trades.iloc[-1]
        st.write(f"Most recent simulated direction: **{t['Direction']}**")
        st.write(f"Simulated entry: **{t['Entry']:.5f}**")
        st.write(f"Hypothetical reference: **{t['Hypothetical risk reference']:.5f}**")
        st.write(f"Virtual stake: **{t['Virtual stake']:.2f}**")
    else:
        st.write("No simulated entries yet, so no reference level is available.")
    st.markdown("### Risk settings")
    st.write(f"Virtual stake per trade: {risk_pct:.1f}% of current simulated balance.")
    st.write(f"Maximum configured stake: 2% of virtual balance.")
    st.write("The simulator uses a fixed virtual stake and does not martingale.")

with tab3:
    st.subheader("Simulated trade history")
    if trades.empty:
        st.info("No trades generated with the selected settings/data.")
    else:
        st.dataframe(trades.iloc[::-1], use_container_width=True, hide_index=True)
        csv_bytes = trades.to_csv(index=False).encode("utf-8")
        st.download_button("Download trade history CSV", csv_bytes, "cart3r_trade_history.csv", "text/csv")

with tab4:
    st.subheader("Performance overview")
    p1, p2, p3, p4 = st.columns(4)
    p1.metric("Wins", wins)
    p2.metric("Losses", losses)
    p3.metric("Draws", draws)
    p4.metric("Profit factor", f"{pf:.2f}" if pd.notna(pf) else "N/A")
    if not trades.empty:
        equity = pd.DataFrame({"Trade": range(1, len(trades)+1), "Balance": trades.Balance})
        efig = go.Figure(go.Scatter(x=equity.Trade, y=equity.Balance, mode="lines", name="Virtual equity"))
        efig.update_layout(template="plotly_dark", height=300, paper_bgcolor="#080808", plot_bgcolor="#080808")
        st.plotly_chart(efig, use_container_width=True)
        st.write("**Important:** Results are historical simulations, not predictions. Check out-of-sample data and realistic assumptions before drawing conclusions.")
    else:
        st.info("Performance charts will appear after simulated trades are generated.")

st.divider()
st.caption("CART3R v2.0 • Educational software • No broker integration • No financial advice")
